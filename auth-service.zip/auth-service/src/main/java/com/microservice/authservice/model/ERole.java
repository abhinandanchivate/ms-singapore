package com.microservice.authservice.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
